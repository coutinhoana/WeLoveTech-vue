<template>
    <div class="in-tech__banner">
        <div class="in-tech__banner--info">
            <p>Para enviar o seu projeto é muito simples!</p>
            <p>Basta enviar para o email <span class="email">vue_womanintech@gmail.com</span> e aguardar o nosso contato!</p>
            <p>Estamos ansiosas para ver o seu trabalho!</p>
        </div>
        <img src="../images/send.png">
    </div>
</template>

<style scoped>
.in-tech__banner {
    text-align: center;
}

.in-tech__banner--info {
    margin: 2rem 0;
}

.email {
    border-bottom: 2px solid pink;
}

img {
    width: 100%;
    padding: 0 9rem 2rem 9rem;
}
</style>